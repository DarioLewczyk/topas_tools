# Authorship: {{{
# Written by Dario Lewczyk
# Date: 06-28-24
#}}}
