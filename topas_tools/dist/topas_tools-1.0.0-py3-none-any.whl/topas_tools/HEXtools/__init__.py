# Authorship:{{{
'''
Written by Dario Lewczyk
Date: 03/13/2024
Usage: For working with data from HEX beamline
'''
#}}}
