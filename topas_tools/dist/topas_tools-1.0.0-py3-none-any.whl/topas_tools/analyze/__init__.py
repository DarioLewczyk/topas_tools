# Authorship: {{{
# Written by Dario Lewczyk
# 02-20-2024
#}}}

